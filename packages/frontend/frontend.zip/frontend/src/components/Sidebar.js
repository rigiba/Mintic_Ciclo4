import { Link } from 'react-router-dom'
const Sidebar = ()=>{
    return (
        <div className="sidebar">
            <ul>
                <li>
                    <Link to="/" className='btn btn-primary'>Servicios</Link>
                </li>               
                <li>
                    <Link to="/usuarios" className='btn btn-secondary'>Usuarios</Link> 
                </li>
            </ul>
        </div>
    )
}
export default Sidebar