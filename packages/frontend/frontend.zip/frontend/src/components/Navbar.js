const Navbar = () =>{
    return (
        <div className="navbar">
          <h1>  Administracion de estacionamiento</h1>
        </div>
    )
}
export default Navbar