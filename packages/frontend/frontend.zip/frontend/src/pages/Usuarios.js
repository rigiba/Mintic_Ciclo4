import TablaDatos from './TablaDatos'


const Usuarios=()=>{
    return (
        <div>
            <TablaDatos/>
        </div>
        )

 }
 export default Usuarios